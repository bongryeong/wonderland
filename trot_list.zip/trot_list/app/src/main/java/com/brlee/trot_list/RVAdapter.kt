package com.brlee.trot_list

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class RVAdapter(val items: MutableList<String>) : RecyclerView.Adapter<RVAdapter.ViewHolder>() {
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RVAdapter.ViewHolder {
        TODO("Not yet implemented")
        // 어댑터에 연결 하는법  rv_item 레이아웃
        val view = LayoutInflater.from(parent.context).inflate(R.layout.rv_item,parent,false)

        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: RVAdapter.ViewHolder, position: Int) {
        TODO("Not yet implemented")
        holder.bindItems(items[position])
    }

    override fun getItemCount(): Int {
        TODO("Not yet implemented")
        return items.size
    }

    inner class  ViewHolder(itemView : View) : RecyclerView.ViewHolder(itemView) {
        fun bindItems(item : String) {

            val rv_text = itemView.findViewById<TextView>(R.id.rvTextId)
            rv_text.text = item

        }
    }
}